using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using DG.Tweening;
using UnityEngine.UI;

public class TitleItem : MonoBehaviour,IPointerClickHandler
{
    public Text title;
    bool flag;
    private Transform Panel;
    // Start is called before the first frame update
    void Start()
    {
        title = transform.GetChild(0).GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void SetName(FoldDate date)
    {
        title.text = date.Name;  
    }
    public void SetPanel(GameObject pan)
    {
        Panel = pan.transform;
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (flag)
        {
            flag = false;
            if (Panel!=null)
            {
                Panel.gameObject.SetActive(true);
                Panel.DOScaleY(1, 0.2f);
            }
        }
        else
        {
            flag = true;
            if (Panel != null)
            {
                Panel.DOScaleY(0, 0.2f).OnComplete(() => { Panel.gameObject.SetActive(false); });
            }
        }
    }
}
