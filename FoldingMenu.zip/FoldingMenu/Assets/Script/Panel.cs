using Newtonsoft.Json;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
public class tittleDate
{
    public string Name;
}
public class FoldDate
{
    public string Name;
    public List<tittleDate> tittles;
}
public class Panel : MonoBehaviour
{
    public List<FoldDate> folders=new List<FoldDate>();
    private void Awake()
    {
        folders = JsonConvert.DeserializeObject<List<FoldDate>>(File.ReadAllText("1.json"));
    }
    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < folders.Count; i++)
        {
            GameObject title=Instantiate(Resources.Load<GameObject>("TitleItem"),transform);
            title.GetComponent<TitleItem>().SetName(folders[i]);

            GameObject panel= Instantiate(Resources.Load<GameObject>("Panel"), transform);
            panel.SetActive(false);
            title.GetComponent<TitleItem>().SetPanel(panel);

            for (int j = 0; j < folders[i].tittles.Count; j++)
            {
                GameObject dateitem = Instantiate(Resources.Load<GameObject>("DateItem"), panel.transform);
                dateitem.GetComponent<DateItem>().SetName(folders[i].tittles[j]);
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
