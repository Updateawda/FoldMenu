using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DateItem : MonoBehaviour
{
    public Text datename;
    // Start is called before the first frame update
    void Start()
    {
        datename=transform.GetChild(0).GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void SetName(tittleDate date)
    {
        datename.text = date.Name;
    }
}
